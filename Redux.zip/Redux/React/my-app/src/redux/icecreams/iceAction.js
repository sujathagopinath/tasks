import { BUY_ICE } from './iceType'

export const buyice = () => {
    return {
        type: BUY_ICE,
        loading: true
    }
}