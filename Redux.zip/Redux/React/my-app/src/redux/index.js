export { buycake } from './cakes/cakeAction'
export { buyice } from './icecreams/iceAction'