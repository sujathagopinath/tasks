

var Firstname = document.getElementById("Name").value;
var Lastname = document.getElementById("Name").value;
var company = document.getElementById("company").value;
var email = document.getElementById("email").value;
var phonenumber = document.getElementById("phno").value;
function register() {
    // name validation
    if (Firstname.value == "") {
        Firstname.style.border = "1px solid red";
    }
    if (Lastname.value == "") {
        document.getElementById("name").innerHTML = "valid"
        document.getElementById("name").style.visibility = "visible";
        document.getElementById("name").style.color = "green";
    }
    else {
        document.getElementById("company").innerHTML = "valid"
        document.getElementById("company").style.visibility = "visible";
        document.getElementById("company").style.color = "green";

    }

    //company name validation

    if (company.value == "") {
        document.getElementById("company").innerHTML = "valid"
        document.getElementById("company").style.visibility = "visible";
        document.getElementById("company").style.color = "green";

    }
    else {
        document.getElementById("company").innerHTML = "Invalid"
        document.getElementById("company").style.visibility = "visible";
        document.getElementById("company").style.color = "red";
    }

    // email validation

    var reg = /^([a-z A-z 0-9 \.-]+)@([a-z A-z 0-9]+).([a-z]{2,10}) .([a-z]{2,4}?)$/;
    if (reg.test(email)) {
        document.getElementById("email").innerHTML = "valid"
        document.getElementById("email").style.visibility = "visible";
        document.getElementById("email").style.color = "green";
    }
    else {
        document.getElementById("email").innerHTML = "Invalid"
        document.getElementById("email").style.visibility = "visible";
        document.getElementById("email").style.color = "red";
    }

    //phonenumber validation
    var regx = /^[7-9]\d{9}$/;

    if (regx.test(phonenumber)) {
        document.getElementById("phno").innerHTML = "valid"
        document.getElementById("phno").style.visibility = "visible";
        document.getElementById("phno").style.color = "green";
    }
    else {
        document.getElementById("phno").innerHTML = "Invalid"
        document.getElementById("phno").style.visibility = "visible";
        document.getElementById("phno").style.color = "red";
    }

}