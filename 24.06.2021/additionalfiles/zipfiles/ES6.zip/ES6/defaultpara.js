// window.onload = function () {
//     function add(num = 10) {
//         console.log(num);
//     }
//     add(5);
//     // add();
// }

window.onload = function () {
    function details(name = "hello", age = 10) {
        console.log('My name is ' + name + ' and age is ' + age);
    }
    // details();
    details("sujatha", 21);
    // console.log("sujatha", 21);
}