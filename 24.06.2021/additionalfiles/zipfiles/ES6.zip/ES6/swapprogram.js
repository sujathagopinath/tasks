//swap using destructing

let a = 10;
let b = 15;
let temp;

temp = a;
a = b;
b = temp;
console.log(a);
console.log(b);