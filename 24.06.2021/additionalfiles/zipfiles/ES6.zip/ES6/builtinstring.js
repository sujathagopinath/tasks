//charAt

var data = "hello world";
var data1 = "hi";
console.log(data.charAt(1));

console.log(data.charCodeAt(2));

console.log(data.concat(data1));

console.log(data.endsWith("d"));

console.log(data.endsWith("i"));

console.log(String.fromCharCode("73"));

console.log(data.includes("world", 1))

console.log(data.indexOf("hello")); //emoji try 
