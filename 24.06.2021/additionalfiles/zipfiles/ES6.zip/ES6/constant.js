window.onload = function () {
    const pi = 3.14;

    // console.log(pi);

    function calarea(r) {
        const pi = 5;
        console.log("the area is: " + pi * r * r);
    }
    console.log(pi);
    calarea(5);
}