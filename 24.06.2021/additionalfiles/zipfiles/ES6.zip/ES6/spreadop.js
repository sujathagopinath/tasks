// const data1 = {
//     name: 'AAA',
//     age: 12
// };

// const data2 = {
//     name: 'BBB',
//     location: 'Chennai'
// }

// const merge = { ...data1, ...data2 };
// console.log(merge);

const data1 = {
    name: 'AAA',
    age: 21
};
const data2 = data1;
console.log(data2);