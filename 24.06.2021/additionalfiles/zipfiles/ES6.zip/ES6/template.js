window.onload = function () {
    // var temp = `hello, my name is madhu`;

    // console.log(temp);

    function details(name, age) {
        console.log(`My name is ${name}  and age is ${age}`);
        //and age is${10+12};
    }
    details("sujatha", 21);
}