const secret = 'secretkey';

module.exports = secret;